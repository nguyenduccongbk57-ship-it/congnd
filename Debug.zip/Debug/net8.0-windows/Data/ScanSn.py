import os
import cv2
import numpy as np
import pytesseract
from pytesseract import Output
import re

# =====================================================
# CONFIG
# =====================================================

pytesseract.pytesseract.tesseract_cmd = \
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"

BASE = os.path.dirname(__file__)

INPUT_IMAGE = os.path.join(BASE, "capture.bmp")

DEBUG_DIR = os.path.join(BASE, "Debug")
os.makedirs(DEBUG_DIR, exist_ok=True)

LABEL_PAD = 5

MIN_AREA = 3000
MIN_RATIO = 2.5

TEXT_TOP = 0.65
TEXT_BOTTOM = 0.90

OCR_SCALE = 5


# =====================================================
# SAVE DEBUG
# =====================================================

def save_debug(name, img):
    cv2.imwrite(os.path.join(DEBUG_DIR, name), img)


# =====================================================
# FIND LABEL
# =====================================================

def find_label(img):

    save_debug("01_original.jpg", img)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    _, th = cv2.threshold(
        gray,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    save_debug("02_threshold.jpg", th)

    kernel = cv2.getStructuringElement(
        cv2.MORPH_RECT,
        (7, 7)
    )

    close = cv2.morphologyEx(
        th,
        cv2.MORPH_CLOSE,
        kernel
    )

    contours, _ = cv2.findContours(
        close,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    draw = img.copy()

    best = None
    best_area = 0

    for c in contours:

        area = cv2.contourArea(c)

        if area < MIN_AREA:
            continue

        x, y, w, h = cv2.boundingRect(c)

        ratio = w / float(h)

        if ratio < MIN_RATIO:
            continue

        cv2.rectangle(
            draw,
            (x, y),
            (x + w, y + h),
            (0, 255, 0),
            2
        )

        if area > best_area:
            best_area = area
            best = (x, y, w, h)

    save_debug("03_candidate.jpg", draw)

    if best is None:
        return None

    x, y, w, h = best

    x = max(0, x - LABEL_PAD)
    y = max(0, y - LABEL_PAD)

    w = min(img.shape[1] - x, w + LABEL_PAD * 2)
    h = min(img.shape[0] - y, h + LABEL_PAD * 2)

    label = img[y:y + h, x:x + w]

    save_debug("04_label.jpg", label)

    return label


# =====================================================
# CROP TEXT
# =====================================================

def crop_text(label):

    label = cv2.rotate(
        label,
        cv2.ROTATE_180
    )

    save_debug("05_rotate.jpg", label)

    H, W = label.shape[:2]

    text = label[
        int(H * TEXT_TOP):int(H * TEXT_BOTTOM),
        0:W
    ]

    save_debug("06_text.jpg", text)

    return text

# =====================================================
# OCR
# =====================================================

def run_ocr(img, title):

    config = (
        "--oem 3 "
        "--psm 7 "
        "-c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    )

    data = pytesseract.image_to_data(
        img,
        config=config,
        output_type=pytesseract.Output.DICT
    )

    text = "".join(data["text"]).replace(" ", "").strip()

    confs = []

    for c in data["conf"]:
        try:
            v = float(c)
            if v >= 0:
                confs.append(v)
        except:
            pass

    conf = np.mean(confs) if len(confs) else 0

    print()
    print("=" * 60)
    print(title)
    print("=" * 60)
    print("Text :", text)
    print("Conf :", round(conf, 2))

    return text, conf

# =====================================================
# NORMALIZE SN
# =====================================================

def normalize_sn(text):
    text = text.strip().upper()

    if len(text) != 6:
        return None

    chars = list(text)

    # First 2 positions must be letters: 0 -> O
    for i in range(2):
        if chars[i] == "0":
            chars[i] = "O"

    # Last 4 positions must be digits: O -> 0
    for i in range(2, 6):
        if chars[i] == "O":
            chars[i] = "0"

    sn = "".join(chars)

    if not re.fullmatch(r"[A-Z]{2}[0-9]{4}", sn):
        return None

    return sn


# =====================================================
# MAIN
# =====================================================

def main():

    img = cv2.imread(INPUT_IMAGE)

    if img is None:
        print("FinalResult:Fail")
        return

    label = find_label(img)

    if label is None:
        print("FinalResult:Fail")
        return

    print("Label Found")

    text_img = crop_text(label)

    text, conf = run_ocr(text_img, "OCR")

    sn = normalize_sn(text)

    if sn is None:
        print("FinalResult:Fail")
        return

    print("Normalized :", sn)
    print("FinalResult:True-" + sn)
    print("Confidence:", round(conf, 2))


# =====================================================
# ENTRY
# =====================================================

if __name__ == "__main__":
    main()
